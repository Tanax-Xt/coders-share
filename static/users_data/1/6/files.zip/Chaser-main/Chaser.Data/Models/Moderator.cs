namespace Chaser.Data;

/// <summary>
/// Represents a user database entity in the Discord.
/// </summary>
public class Moderator : DbEntity { }
