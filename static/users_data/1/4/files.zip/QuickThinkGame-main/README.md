# QuickThink Game

The best mobile Java game of the HSE Summer School of Software Engineering

Graduation team project

QuickThink is a mindfulness game with several game modes aimed at developing reaction speed, improving attention and memory training

https://drive.google.com/file/d/1A0XX165EKdy3ug9hou7jRbmfEw3_3Z9Y/view?usp=drive_link
