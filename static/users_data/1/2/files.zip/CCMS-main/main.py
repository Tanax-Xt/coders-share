from app import startup

if __name__ == "__main__":
    import sys

    sys.exit(startup.run())
