<p><img align="center" src="https://readme-typing-svg.herokuapp.com?font=Fira+Code&pause=1300&color=9561CE&width=435&lines=%F0%9F%91%8B+Hi%2C+it's+QuickThink+Desktop+%F0%9F%8F%86" alt="Digital journal.Desktop" /></p>

# QuickThink Desktop

QuickThink is a mindfulness game with several game modes aimed at developing reaction speed, improving attention and memory training

>_Specially for the Lyceum of the Yandex Academy_
