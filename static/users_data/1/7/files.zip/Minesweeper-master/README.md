Minesweeper
===========

A c++ Minesweeper game

Minesweeper lets you specify width, height, and number of mines. It also keeps track of how long you are taking.
